
/*
 *	Version
 */

function Version(nbr, str)
{
	this.number = nbr;
	this.string = str;
}

